## Credits
The login phase, and the panopt video downloading is not my own work.

## Requirements

### Python

If you have pip installed, call `pip install -r requirements.txt`.
If not, install pip and then call it.
If you don't want to use pip, you're smart enough to figure things out.

### Wget

If your on linux, simply get `wget` from your package manager.

If your on windows, get `wget` online and use the `-w`/`--wget-path` option to point the program to the `wget` binary.
